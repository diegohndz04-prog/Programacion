const coloresTexto = ['red', 'blue', 'green', 'orange', 'purple', 'black'];
let indiceTexto = 0;

const coloresFondo = ['#f0f8ff', '#ffe4e1', '#fafad2', '#e6e6fa', '#fffacd', '#d3ffce'];
let indiceFondo = 0;

const titulo = document.getElementById('titulo');
const btnTexto = document.getElementById('btnTexto');
const btnFondo = document.getElementById('btnFondo');

btnTexto.addEventListener('click', () => {
  titulo.style.color = coloresTexto[indiceTexto];
  indiceTexto = (indiceTexto + 1) % coloresTexto.length;
});

btnFondo.addEventListener('click', () => {
  document.body.style.backgroundColor = coloresFondo[indiceFondo];
  indiceFondo = (indiceFondo + 1) % coloresFondo.length;
});
