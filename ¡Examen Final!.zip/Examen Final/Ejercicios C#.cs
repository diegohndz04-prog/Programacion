using System;

class Program
{
    static void Main(string[] args)
    {
        // Ejercicio 1: Sumadora Simple
        Console.WriteLine("Ejercicio 1: Sumadora Simple");
        Console.Write("Introduce el primer número: ");
        int num1 = Convert.ToInt32(Console.ReadLine());
        Console.Write("Introduce el segundo número: ");
        int num2 = Convert.ToInt32(Console.ReadLine());
        int suma = num1 + num2;
        Console.WriteLine($"La suma de {num1} y {num2} es {suma}\n");

        // Ejercicio 2: Tabla de Multiplicar
        Console.WriteLine("Ejercicio 2: Tabla de Multiplicar");
        Console.Write("Introduce un número entero: ");
        int numero = Convert.ToInt32(Console.ReadLine());
        for (int i = 1; i <= 10; i++)
        {
            Console.WriteLine($"{numero} x {i} = {numero * i}");
        }
        Console.WriteLine();

        // Ejercicio 3: Comprobador de Números Pares o Impares
        Console.WriteLine("Ejercicio 3: Comprobador de Números Pares o Impares");
        Console.Write("Introduce un número: ");
        int numeroComprobar = Convert.ToInt32(Console.ReadLine());
        if (numeroComprobar % 2 == 0)
        {
            Console.WriteLine($"{numeroComprobar} es un número par.\n");
        }
        else
        {
            Console.WriteLine($"{numeroComprobar} es un número impar.\n");
        }

        // Ejercicio 4: Función de Saludo
        Console.WriteLine("Ejercicio 4: Función de Saludo");
        Saludar("Juan"); // Puedes cambiar "Juan" por cualquier nombre.
        
        // Ejercicio 5: Recorrer un Array
        Console.WriteLine("Ejercicio 5: Recorrer un Array");
        string[] diasDeLaSemana = { "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo" };
        
        foreach (string dia in diasDeLaSemana)
        {
            Console.WriteLine(dia);
        }
    }

    // Método para saludar
    static void Saludar(string nombre)
    {
        Console.WriteLine($"¡Hola, {nombre}!");
    }
}
