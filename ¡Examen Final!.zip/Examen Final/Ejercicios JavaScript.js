//Ejercicio 1
function calculadora(num1, num2, operador) {
    // Manejo de la división por cero
    if (operador === '/' && num2 === 0) {
      return 'Error: División por cero';
    }
  
    // Estructura switch para determinar la operación
    switch (operador) {
      case '+':
        return num1 + num2;
      case '-':
        return num1 - num2;
      case '*':
        return num1 * num2;
      case '/':
        return num1 / num2;
      default:
        return 'Error: Operador no válido';
    }
  }
  
  // Ejemplos de uso:
  console.log(calculadora(10, 5, '+')); // 15
  console.log(calculadora(10, 5, '-')); // 5
  console.log(calculadora(10, 5, '*')); // 50
  console.log(calculadora(10, 5, '/')); // 2
  console.log(calculadora(10, 0, '/')); // Error: División por cero



//Ejercicio 2
function filtrarPropiedad(arr, prop, val) {
    // La función filter() crea un nuevo array con todos los elementos que pasan la prueba.
    return arr.filter(objeto => objeto[prop] === val);
  }
  
  // Ejemplo de uso:
  const personas = [
    { nombre: 'Ana', edad: 25 },
    { nombre: 'Luis', edad: 30 },
    { nombre: 'Pedro', edad: 25 },
    { nombre: 'Maria', edad: 35 }
  ];
  
  const personasDe25 = filtrarPropiedad(personas, 'edad', 25);
  console.log(personasDe25);
  // Output: [{ nombre: 'Ana', edad: 25 }, { nombre: 'Pedro', edad: 25 }]
  
  const luis = filtrarPropiedad(personas, 'nombre', 'Luis');
  console.log(luis);
  // Output: [{ nombre: 'Luis', edad: 30 }]



//Ejercicio 3
function encontrarMaximo(arr) {
    if (arr.length === 0) {
      return undefined; // o null, dependiendo de lo que se desee devolver en un array vacío
    }
  
    let maximo = arr[0];
    for (let i = 1; i < arr.length; i++) {
      if (arr[i] > maximo) {
        maximo = arr[i];
      }
    }
    return maximo;
  }
  
  // Ejemplo de uso:
  const numeros = [1, 5, 2, 8, 3];
  console.log(encontrarMaximo(numeros)); // 8



//Ejercicio 4
const transacciones = [
    { tipo: 'ingreso', monto: 100 },
    { tipo: 'gasto', monto: 50 },
    { tipo: 'ingreso', monto: 200 },
    { tipo: 'gasto', monto: 75 }
  ];
  
  // El valor inicial del acumulador (acc) es 0
  const balanceFinal = transacciones.reduce((acc, transaccion) => {
    if (transaccion.tipo === 'ingreso') {
      return acc + transaccion.monto;
    } else {
      return acc - transaccion.monto;
    }
  }, 0);
  
  console.log(`El balance final es: ${balanceFinal}`); // El balance final es: 175



//Ejercicio 5
function concatenarArrays(arr1, arr2) {
    // Usamos el spread operator para crear un nuevo array con los elementos de arr1 y arr2.
    return [...arr1, ...arr2];
  }
  
  // Ejemplo de uso:
  const array1 = [1, 2, 3];
  const array2 = [4, 5, 6];
  
  const arrayConcatenado = concatenarArrays(array1, array2);
  
  console.log(arrayConcatenado); // [1, 2, 3, 4, 5, 6]
  console.log(array1); // [1, 2, 3] (se mantiene sin cambios)