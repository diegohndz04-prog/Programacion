//Ejercicio 1
<?php
echo "--- Ejercicio 1: Conversor de Array a JSON ---" . PHP_EOL;

$usuario = [
    "id" => 123,
    "nombre" => "Juan Pérez",
    "email" => "juan.perez@example.com",
    "roles" => ["admin", "editor"]
];

$json_usuario = json_encode($usuario, JSON_PRETTY_PRINT);

echo $json_usuario . PHP_EOL . PHP_EOL;

?>



//Ejercicio 2
<?php
echo "--- Ejercicio 2: Frecuencia de Palabras ---" . PHP_EOL;

function obtenerFrecuenciaPalabras($texto) {
    // Convertir a minúsculas para un conteo no sensible a mayúsculas
    $texto_limpio = strtolower($texto);
    // Reemplazar los signos de puntuación con espacios
    $texto_limpio = str_replace([',', '.', '!', '?', ';', ':'], ' ', $texto_limpio);
    // Dividir el texto en un array de palabras
    $palabras = explode(' ', $texto_limpio);
    // Contar la frecuencia de cada palabra y filtrar elementos vacíos
    $frecuencia = array_count_values(array_filter($palabras));
    
    return $frecuencia;
}

$ejemplo_texto = "Hola mundo, este es un ejemplo. Hola de nuevo, mundo.";
$frecuencia_palabras = obtenerFrecuenciaPalabras($ejemplo_texto);

print_r($frecuencia_palabras);
echo PHP_EOL . PHP_EOL;

?>



//Ejercicio 3
<?php
echo "--- Ejercicio 3: Comprobar si un Número es Primo ---" . PHP_EOL;

function esPrimo($numero) {
    if ($numero <= 1) {
        return false;
    }
    if ($numero <= 3) {
        return true;
    }
    if ($numero % 2 == 0 || $numero % 3 == 0) {
        return false;
    }
    for ($i = 5; $i * $i <= $numero; $i = $i + 6) {
        if ($numero % $i == 0 || $numero % ($i + 2) == 0) {
            return false;
        }
    }
    return true;
}

echo "¿Es 7 un número primo? " . (esPrimo(7) ? "Sí" : "No") . PHP_EOL;
echo "¿Es 10 un número primo? " . (esPrimo(10) ? "Sí" : "No") . PHP_EOL;
echo "---" . PHP_EOL . PHP_EOL;

?>



//Ejercicio 4
<?php
echo "--- Ejercicio 4: Invertir una Cadena de Texto ---" . PHP_EOL;

function invertirCadena($cadena) {
    return strrev($cadena);
}

$texto_original = "Hola mundo";
$texto_invertido = invertirCadena($texto_original);

echo "Cadena original: " . $texto_original . PHP_EOL;
echo "Cadena invertida: " . $texto_invertido . PHP_EOL . PHP_EOL;

?>



//Ejercicio 5
<?php
echo "--- Ejercicio 5: Generador de Contraseñas Aleatorias ---" . PHP_EOL;

function generarContrasena($longitud, $incluir_especiales = false) {
    $caracteres = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    if ($incluir_especiales) {
        $caracteres .= '!@#$%^&*()-_[]{}<>~`+=';
    }
    $contrasena = '';
    $max = strlen($caracteres) - 1;
    for ($i = 0; $i < $longitud; $i++) {
        $contrasena .= $caracteres[mt_rand(0, $max)];
    }
    return $contrasena;
}

$contrasena_simple = generarContrasena(8);
$contrasena_compleja = generarContrasena(12, true);

echo "Contraseña de 8 caracteres (sin especiales): " . $contrasena_simple . PHP_EOL;
echo "Contraseña de 12 caracteres (con especiales): " . $contrasena_compleja . PHP_EOL . PHP_EOL;

?>