#Ejercicio 1
print("Ejercicio 1")
def transformar_matriz(matriz, numero):
    """
    Multiplica cada elemento de una matriz por un número dado.

    :param matriz: Una lista de listas de números.
    :param numero: El número entero por el que se multiplicará.
    :return: Una nueva matriz con los elementos transformados.
    """
    return [[elemento * numero for elemento in fila] for fila in matriz]

# Ejemplo de uso:
matriz_original = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
num_multiplicador = 10
matriz_transformada = transformar_matriz(matriz_original, num_multiplicador)

print(f"Matriz original: {matriz_original}")
print(f"Matriz transformada: {matriz_transformada}")



#Ejercicio 2
print("Ejercicio 2")
def ordenar_por_puntuacion(lista_tuplas):
    """
    Ordena una lista de tuplas (nombre, puntuación) de forma descendente.

    :param lista_tuplas: Lista de tuplas con nombres y puntuaciones.
    :return: La lista ordenada.
    """
    return sorted(lista_tuplas, key=lambda x: x[1], reverse=True)

# Ejemplo de uso:
jugadores = [('Juan', 150), ('Ana', 300), ('Carlos', 100), ('Maria', 250)]
jugadores_ordenados = ordenar_por_puntuacion(jugadores)

print(f"Lista original: {jugadores}")
print(f"Lista ordenada por puntuación (descendente): {jugadores_ordenados}")



#Ejercicio 3
print("Ejercicio 3")
def producto_recursivo(lista_numeros):
    """
    Calcula el producto de todos los números en una lista de forma recursiva.

    :param lista_numeros: La lista de números.
    :return: El producto de los elementos de la lista.
    """
    if not lista_numeros:
        return 1
    else:
        return lista_numeros[0] * producto_recursivo(lista_numeros[1:])

# Ejemplo de uso:
numeros1 = [1, 2, 3, 4]
numeros2 = [5, 10]
numeros3 = []

print(f"Producto de {numeros1}: {producto_recursivo(numeros1)}")
print(f"Producto de {numeros2}: {producto_recursivo(numeros2)}")
print(f"Producto de {numeros3}: {producto_recursivo(numeros3)}")


#Ejercicio 4
print("Ejercicio 4")
def aplanar_listas(*listas):
    """
    Combina múltiples listas en una sola lista aplanada.

    :param listas: Un número variable de listas.
    :return: Una única lista aplanada.
    """
    return [elemento for lista in listas for elemento in lista]

# Ejemplo de uso:
lista_a = [1, 2, 3]
lista_b = ['a', 'b', 'c']
lista_c = [True, False]

lista_aplanada = aplanar_listas(lista_a, lista_b, lista_c)

print(f"Listas de entrada: {lista_a}, {lista_b}, {lista_c}")
print(f"Lista aplanada: {lista_aplanada}")



#Ejercicio 5
print("Ejercicio 5")
def filtrar_por_longitud(lista_palabras, longitud_minima):
    """
    Filtra una lista de palabras para incluir solo aquellas con una longitud mayor que un valor dado.

    :param lista_palabras: La lista de strings (palabras).
    :param longitud_minima: El número entero que define la longitud mínima requerida.
    :return: Una nueva lista con las palabras filtradas.
    """
    return [palabra for palabra in lista_palabras if len(palabra) > longitud_minima]

# Ejemplo de uso:
palabras = ['manzana', 'sol', 'elefante', 'python', 'gato']
min_longitud = 5

palabras_filtradas = filtrar_por_longitud(palabras, min_longitud)

print(f"Lista de palabras original: {palabras}")
print(f"Palabras con longitud mayor a {min_longitud}: {palabras_filtradas}")