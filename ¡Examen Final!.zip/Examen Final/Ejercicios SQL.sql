// Ejercicio 1
SELECT nombre, email 
FROM usuarios 
WHERE fecha_registro > '2023-01-01';



//Ejercicio 2
INSERT INTO usuarios (nombre, email, fecha_registro) 
VALUES ('Tu Nombre', 'tu.email@example.com', CURDATE());



//Ejercicio 3
UPDATE usuarios 
SET email = 'nuevo.email@example.com' 
WHERE id = 5;



//Ejercicio 4
SELECT producto, monto 
FROM pedidos 
ORDER BY monto DESC;



//Ejercicio 5
SELECT u.nombre, p.producto 
FROM usuarios u 
INNER JOIN pedidos p ON u.id = p.usuario_id;